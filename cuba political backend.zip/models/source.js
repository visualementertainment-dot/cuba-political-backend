const mongoose = require('mongoose');

const sourceSchema = new mongoose.Schema({
  id: { type: String, unique: true, required: true },
  name: String,
  icon: String,
  color: String,
  category: String,
});

module.exports = mongoose.model('Source', sourceSchema);
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const connectDB = require('./config/db');
const compression = require('compression');
const { PORT, isProduction } = require('./config/env');
const errorHandler = require('./middleware/errorHandler');


// Importar rutas
const authRoutes = require('./routes/authRoutes');
const newsRoutes = require('./routes/newsRoutes');
const userRoutes = require('./routes/userRoutes');
const commentRoutes = require('./routes/commentRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const sourceRoutes = require('./routes/sourceRoutes');
const adminRoutes = require('./routes/adminRoutes');

const app = express();

// Seguridad
app.use(helmet());
app.use(cors({ origin: isProduction ? 'https://tudominio.com' : '*' }));
app.use(compression());
app.use(express.json({ limit: '10kb' }));

// Rate limiting global
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Demasiadas peticiones, intente más tarde.' }
});
app.use('/api/', limiter);

// Rate limiting específico para autenticación
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  skipSuccessfulRequests: true,
});
app.use('/api/auth/', authLimiter);

// Conectar a MongoDB y sembrar datos


// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/news', newsRoutes);
app.use('/api/user', userRoutes);
app.use('/api/comments', commentRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/sources', sourceRoutes);
app.use('/api/admin', adminRoutes);

// Manejador de errores global (siempre al final)
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`🚀 Servidor escalable corriendo en puerto ${PORT} (${process.env.NODE_ENV || 'development'})`);
});
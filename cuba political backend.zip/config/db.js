const mongoose = require('mongoose');
const { MONGODB_URI } = require('./env');

const connectDB = async () => {
  mongoose.set('strictQuery', false);
  await mongoose.connect(MONGODB_URI, {
    maxPoolSize: 10,
  });
  console.log('✅ Conectado a MongoDB');
};

module.exports = connectDB;
const requiredEnv = ['JWT_SECRET', 'MONGODB_URI'];
for (const env of requiredEnv) {
  if (!process.env[env]) {
    throw new Error(`Falta variable de entorno: ${env}`);
  }
}

module.exports = {
  PORT: process.env.PORT || 5000,
  JWT_SECRET: process.env.JWT_SECRET,
  MONGODB_URI: process.env.MONGODB_URI,
  NODE_ENV: process.env.NODE_ENV || 'development',
  isProduction: process.env.NODE_ENV === 'production'
};
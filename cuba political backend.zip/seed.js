const mongoose = require("mongoose");
const Source = require("./models/Source");
const connectDB = require("./config/db");

async function seedDatabase() {
  try {
    // Conectar a MongoDB
    await connectDB();

    console.log("🌱 Insertando fuentes...");

    // Borrar las existentes
    await Source.deleteMany({});

    // Insertar nuevas
    await Source.insertMany([
      {
        id: "granma",
        name: "Granma",
        icon: "📰",
        color: "#d32f2f",
        category: "Prensa",
      },
      {
        id: "juventud-rebelde",
        name: "Juventud Rebelde",
        icon: "🗞️",
        color: "#1976d2",
        category: "Prensa",
      },
      {
        id: "trabajadores",
        name: "Trabajadores",
        icon: "📄",
        color: "#388e3c",
        category: "Prensa",
      },
      {
        id: "cubadebate",
        name: "Cubadebate",
        icon: "💬",
        color: "#f57c00",
        category: "Digital",
      },
      {
        id: "acn",
        name: "Agencia Cubana de Noticias",
        icon: "📢",
        color: "#7b1fa2",
        category: "Agencia",
      },
    ]);

    console.log("✅ Fuentes insertadas correctamente");
  } catch (err) {
    console.error("❌ Error:", err);
  } finally {
    // Cerrar la conexión
    await mongoose.connection.close();
    process.exit(0);
  }
}

// Ejecutar el seed
seedDatabase();const mongoose = require("mongoose");
const Source = require("./models/Source");
const connectDB = require("./config/db");

async function seedDatabase() {
  try {
    // Conectar a MongoDB
    await connectDB();

    console.log("🌱 Insertando fuentes...");

    // Borrar las existentes
    await Source.deleteMany({});

    // Insertar nuevas
    await Source.insertMany([
      {
        id: "granma",
        name: "Granma",
        icon: "📰",
        color: "#d32f2f",
        category: "Prensa",
      },
      {
        id: "juventud-rebelde",
        name: "Juventud Rebelde",
        icon: "🗞️",
        color: "#1976d2",
        category: "Prensa",
      },
      {
        id: "trabajadores",
        name: "Trabajadores",
        icon: "📄",
        color: "#388e3c",
        category: "Prensa",
      },
      {
        id: "cubadebate",
        name: "Cubadebate",
        icon: "💬",
        color: "#f57c00",
        category: "Digital",
      },
      {
        id: "acn",
        name: "Agencia Cubana de Noticias",
        icon: "📢",
        color: "#7b1fa2",
        category: "Agencia",
      },
    ]);

    console.log("✅ Fuentes insertadas correctamente");
  } catch (err) {
    console.error("❌ Error:", err);
  } finally {
    // Cerrar la conexión
    await mongoose.connection.close();
    process.exit(0);
  }
}

// Ejecutar el seed
seedDatabase();
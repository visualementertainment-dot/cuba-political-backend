const User = require('../models/User');

async function adminMiddleware(req,res,next){
  if(req.user && req.user.isAdmin) return next();
  const user=await User.findById(req.userId).select('isAdmin');
  if(!user || !user.isAdmin) return res.status(403).json({error:'Acceso de administrador requerido'});
  next();
}
module.exports=adminMiddleware;

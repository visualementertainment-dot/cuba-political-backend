const Article = require('../models/Article');
const asyncHandler = require('../utils/asyncHandler');

exports.getNews = asyncHandler(async (req, res) => {
  const { sources, page = 1, limit = 20, urgent, category } = req.query;
  const filter = {};
  if (sources) filter.source = { $in: sources.split(',') };
  if (urgent === 'true') filter.urgent = true;
  if (category) filter.category = category;

  const pageNum = Math.max(1, parseInt(page));
  const limitNum = Math.min(100, parseInt(limit));
  const skip = (pageNum - 1) * limitNum;

  const [articles, total] = await Promise.all([
    Article.find(filter).sort({ publishedAt: -1 }).skip(skip).limit(limitNum),
    Article.countDocuments(filter)
  ]);
  res.json({ articles, total, page: pageNum, totalPages: Math.ceil(total / limitNum) });
});

exports.getArticleById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!id.match(/^[0-9a-fA-F]{24}$/)) return res.status(400).json({ error: 'ID inválido' });
  const article = await Article.findById(id);
  if (!article) return res.status(404).json({ error: 'No encontrado' });
  await article.updateOne({ $inc: { reads: 1 } });
  article.reads += 1;
  res.json(article);
});